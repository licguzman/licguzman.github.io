Animated Page Transition #2
=========

An ajax powered page transition, with a slide-in content animation triggered by a side tabbed navigation.

[Article on CodyHouse](http://codyhouse.co/gem/animated-page-transition-2/)

[Demo](http://codyhouse.co/demo/animated-page-transition-2/index.html)

Icons: [Nucleo](https://nucleoapp.com/)
 
[Terms](http://codyhouse.co/terms/)
